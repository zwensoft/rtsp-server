/*
 * ffmpeg_demux.c
 *
 *  Created on: Apr 25, 2016
 *      Author: chenxh
 */


#include "ffmpeg_demux.h"
#include "libavformat/avformat.h"
#include "libavformat/avio.h"

int main(int argc, char **argv) {
	av_register_all();

	return 0;
}

