/*
 * FFmpedDemux.h
 *
 *  Created on: Apr 25, 2016
 *      Author: chenxh
 */

#ifndef FFMPEG_DEMUX_H_
#define FFMPEG_DEMUX_H_

struct FFmpegDemuxContext {

};

#endif /* FFMPEG_DEMUX_H_ */
